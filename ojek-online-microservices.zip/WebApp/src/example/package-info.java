@javax.xml.bind.annotation.XmlSchema(namespace = "http://example/")
package example;
